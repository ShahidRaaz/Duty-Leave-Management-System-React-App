import React from 'react';
class RejectedS extends React.Component{
  render(){
    return (
      <div className="status">
      <center>
        This contains Rejected status
      </center>
    </div>
    )
  };
}
  export default RejectedS;