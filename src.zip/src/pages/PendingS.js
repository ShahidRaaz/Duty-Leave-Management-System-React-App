import React from 'react';
class PendingS extends React.Component{
  render(){
    return (
      <div className="status">
      <center>
      This contains Pending status
      </center>
    </div>
    )
  };
  }
  export default PendingS;