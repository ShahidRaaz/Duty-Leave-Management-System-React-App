import React from 'react';
class Messages extends React.Component{
  render(){
    return (
    <div>
      <center>
      <div className="content" id="formpage">
      <h1 className="heading">Messages</h1>
      </div>
      </center>
    </div>
    )
  };
}
  export default Messages;