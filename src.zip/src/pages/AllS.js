import './AllS.css'
import React from 'react';
class AllS extends React.Component{
  render(){
    return (
      <div className="status">
      <center>
      This contains All status
      </center>
    </div>
    )
  };
}
export default AllS;