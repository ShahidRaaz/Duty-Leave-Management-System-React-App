import React from 'react';
class ApprovedS extends React.Component{
  render(){
    return (
      <div className="status">
      <center>
        This contains Approved status
      </center>
    </div>
    )
  };
}
  export default ApprovedS;